// Data Store
const dashboardData = {
  companies: [
    { name: "TechCorp Global", industry: "Tech", description: "SaaS Cloud Infrastructure Provider" },
    { name: "FinanceFirst Bank", industry: "Finance", description: "Global Financial Services Company" },
    { name: "RetailNow Inc", industry: "Retail", description: "E-Commerce & Physical Retail Chain" }
  ],
  
  finance: {
    ytd_revenue: 8500000000,
    revenue_growth: 0.12,
    gross_margin: 0.425,
    margin_trend: -0.008,
    market_share: 0.182,
    market_share_trend: 0.013,
    cac: 450,
    cac_trend: -0.05,
    ltv: 12500,
    ltv_trend: 0.08,
    ltv_cac_ratio: 27.8,
    attrition_rate: 0.082,
    attrition_trend: 0.011,
    operational_efficiency: 0.873,
    efficiency_trend: 0.021,
    
    revenue_by_segment: [
      { segment: "North America", revenue: 3200000000, percentage: 37.6, color: "#3B82F6" },
      { segment: "Europe", revenue: 2100000000, percentage: 24.7, color: "#8B5CF6" },
      { segment: "Asia-Pacific", revenue: 1800000000, percentage: 21.2, color: "#EC4899" },
      { segment: "Latin America", revenue: 900000000, percentage: 10.6, color: "#F59E0B" },
      { segment: "Other", revenue: 500000000, percentage: 5.9, color: "#6B7280" }
    ],
    
    revenue_forecast: [
      { quarter: "Q2 2024", revenue: 1950000000, historical: true },
      { quarter: "Q3 2024", revenue: 2050000000, historical: true },
      { quarter: "Q4 2024", revenue: 2100000000, historical: true },
      { quarter: "Q1 2025", revenue: 2150000000, historical: true },
      { quarter: "Q2 2025", revenue: 2300000000, forecast: true, upper_bound: 2450000000, lower_bound: 2150000000 },
      { quarter: "Q3 2025", revenue: 2420000000, forecast: true, upper_bound: 2620000000, lower_bound: 2220000000 },
      { quarter: "Q4 2025", revenue: 2500000000, forecast: true, upper_bound: 2750000000, lower_bound: 2250000000 },
      { quarter: "Q1 2026", revenue: 2580000000, forecast: true, upper_bound: 2880000000, lower_bound: 2280000000 }
    ],
    
    margin_trends: [
      { quarter: "Q2 2024", gross_margin: 41.2, operating_margin: 28.5 },
      { quarter: "Q3 2024", gross_margin: 41.5, operating_margin: 29.1 },
      { quarter: "Q4 2024", gross_margin: 41.8, operating_margin: 29.8 },
      { quarter: "Q1 2025", gross_margin: 42.1, operating_margin: 30.2 },
      { quarter: "Q2 2025", gross_margin: 42.5, operating_margin: 30.5 },
      { quarter: "Q3 2025", gross_margin: 42.3, operating_margin: 30.1 },
      { quarter: "Q4 2025", gross_margin: 42.1, operating_margin: 29.8 },
      { quarter: "Q1 2026", gross_margin: 42.0, operating_margin: 29.6 }
    ],
    
    churn_risk_heatmap: {
      segments: ["Enterprise", "Mid-Market", "SMB", "Startups", "Government"],
      regions: ["North America", "Europe", "APAC", "LATAM"],
      risk_matrix: [
        { segment: "Enterprise", risks: [12, 18, 8, 22] },
        { segment: "Mid-Market", risks: [28, 32, 25, 38] },
        { segment: "SMB", risks: [45, 52, 48, 62] },
        { segment: "Startups", risks: [65, 72, 68, 80] },
        { segment: "Government", risks: [8, 12, 6, 18] }
      ]
    },
    
    ai_recommendations: [
      {
        title: "Enhance Enterprise Retention Program",
        impact: "Reduce churn risk by 15%",
        action: "Deploy dedicated success team for top 100 accounts",
        time_to_implement: "4 weeks",
        confidence: 92,
        priority: "high",
        estimated_ltv_uplift: "8.5M"
      },
      {
        title: "Optimize SMB Product Tier",
        impact: "Increase LTV by 22%",
        action: "Launch self-serve analytics dashboard",
        time_to_implement: "8 weeks",
        confidence: 85,
        priority: "high",
        estimated_revenue_uplift: "180M"
      },
      {
        title: "Geographic Expansion to India",
        impact: "Add 12% to APAC revenue",
        action: "Establish local sales office with 15-person team",
        time_to_implement: "12 weeks",
        confidence: 78,
        priority: "medium",
        estimated_market_opportunity: "250M"
      },
      {
        title: "Reduce CAC through Partnerships",
        impact: "Lower CAC by 18%",
        action: "Form strategic partnerships with 5 consulting firms",
        time_to_implement: "6 weeks",
        confidence: 88,
        priority: "medium",
        estimated_savings: "35M"
      },
      {
        title: "Combat Startup Segment Churn",
        impact: "Reduce churn by 25%",
        action: "Create tiered pricing with freemium model",
        time_to_implement: "10 weeks",
        confidence: 81,
        priority: "high",
        estimated_customer_retention: "12000"
      },
      {
        title: "Workforce Optimization",
        impact: "Reduce attrition to 5.5%",
        action: "Launch career development and mentorship program",
        time_to_implement: "14 weeks",
        confidence: 79,
        priority: "medium",
        estimated_retention_savings: "45M"
      }
    ]
  },
  
  scenario_presets: [
    {
      name: "Aggressive Growth",
      description: "High investment for market expansion",
      variables: { marketing_spend: 20, price: -5, hiring_rate: 25, churn_target: -8, cost_efficiency: -2 }
    },
    {
      name: "Conservative",
      description: "Maintain profitability with minimal risk",
      variables: { marketing_spend: -10, price: 8, hiring_rate: 5, churn_target: 2, cost_efficiency: 5 }
    },
    {
      name: "Cost Optimization",
      description: "Improve margins through operational efficiency",
      variables: { marketing_spend: -15, price: 0, hiring_rate: -20, churn_target: 0, cost_efficiency: 15 }
    },
    {
      name: "Market Expansion",
      description: "Enter new geographic markets",
      variables: { marketing_spend: 18, price: 0, hiring_rate: 30, churn_target: -5, cost_efficiency: 8 }
    }
  ]
};

let currentIndustry = 'Tech';
let currentScenario = {
  marketing_spend: 0,
  price: 0,
  hiring_rate: 0,
  churn_target: 0,
  cost_efficiency: 0
};

let charts = {};

// Initialize dashboard
function init() {
  updateClock();
  setInterval(updateClock, 1000);
  
  setupIndustryTabs();
  setupSliders();
  setupPresetButtons();
  setupScenarioButtons();
  setupWhatIfAnalysis();
  
  loadIndustryData(currentIndustry);
  animateKPIs();
  renderCharts();
  renderRecommendations();
}

// Update clock
function updateClock() {
  const now = new Date();
  const options = { 
    weekday: 'short', 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  };
  document.getElementById('currentTime').textContent = now.toLocaleDateString('en-US', options);
}

// Setup industry tabs
function setupIndustryTabs() {
  const tabs = document.querySelectorAll('.industry-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentIndustry = tab.dataset.industry;
      loadIndustryData(currentIndustry);
    });
  });
}

// Load industry data
function loadIndustryData(industry) {
  const company = dashboardData.companies.find(c => c.industry === industry);
  if (company) {
    document.getElementById('companyName').textContent = company.name;
    document.getElementById('companyDescription').textContent = company.description;
  }
  
  // Re-animate KPIs
  animateKPIs();
  
  // Update charts
  if (charts.revenueSegment) {
    updateCharts();
  }
}

// Animate KPI counters
function animateKPIs() {
  const kpiCards = document.querySelectorAll('.kpi-value');
  
  kpiCards.forEach((card, index) => {
    const targetValue = parseFloat(card.dataset.value);
    const duration = 1500;
    const startTime = Date.now();
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      
      let currentValue = targetValue * easeProgress;
      let formattedValue;
      
      switch(index) {
        case 0: // Revenue
          formattedValue = '$' + (currentValue / 1000000000).toFixed(1) + 'B';
          break;
        case 1: // Margin
        case 2: // Market Share
        case 5: // Attrition
        case 7: // Efficiency
          formattedValue = currentValue.toFixed(1) + '%';
          break;
        case 3: // CAC
          formattedValue = '$' + Math.round(currentValue);
          break;
        case 4: // LTV
          formattedValue = '$' + Math.round(currentValue).toLocaleString();
          break;
        case 6: // LTV/CAC
          formattedValue = currentValue.toFixed(1) + 'x';
          break;
        default:
          formattedValue = currentValue.toFixed(1);
      }
      
      card.textContent = formattedValue;
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    
    setTimeout(() => animate(), index * 100);
  });
}

// Setup sliders
function setupSliders() {
  const sliders = [
    { id: 'marketingSlider', valueId: 'marketingValue', key: 'marketing_spend' },
    { id: 'priceSlider', valueId: 'priceValue', key: 'price' },
    { id: 'hiringSlider', valueId: 'hiringValue', key: 'hiring_rate' },
    { id: 'churnSlider', valueId: 'churnValue', key: 'churn_target' },
    { id: 'efficiencySlider', valueId: 'efficiencyValue', key: 'cost_efficiency' }
  ];
  
  sliders.forEach(({ id, valueId, key }) => {
    const slider = document.getElementById(id);
    const valueDisplay = document.getElementById(valueId);
    
    slider.addEventListener('input', (e) => {
      const value = parseInt(e.target.value);
      currentScenario[key] = value;
      valueDisplay.textContent = (value > 0 ? '+' : '') + value + '%';
      calculateScenarioImpact();
    });
  });
}

// Setup preset buttons
function setupPresetButtons() {
  const presetButtons = document.querySelectorAll('.preset-btn');
  presetButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const presetName = btn.dataset.preset;
      const preset = dashboardData.scenario_presets.find(p => p.name === presetName);
      
      if (preset) {
        currentScenario = { ...preset.variables };
        applyScenarioToSliders();
        calculateScenarioImpact();
      }
    });
  });
}

// Apply scenario to sliders
function applyScenarioToSliders() {
  document.getElementById('marketingSlider').value = currentScenario.marketing_spend;
  document.getElementById('marketingValue').textContent = (currentScenario.marketing_spend > 0 ? '+' : '') + currentScenario.marketing_spend + '%';
  
  document.getElementById('priceSlider').value = currentScenario.price;
  document.getElementById('priceValue').textContent = (currentScenario.price > 0 ? '+' : '') + currentScenario.price + '%';
  
  document.getElementById('hiringSlider').value = currentScenario.hiring_rate;
  document.getElementById('hiringValue').textContent = (currentScenario.hiring_rate > 0 ? '+' : '') + currentScenario.hiring_rate + '%';
  
  document.getElementById('churnSlider').value = currentScenario.churn_target;
  document.getElementById('churnValue').textContent = (currentScenario.churn_target > 0 ? '+' : '') + currentScenario.churn_target + '%';
  
  document.getElementById('efficiencySlider').value = currentScenario.cost_efficiency;
  document.getElementById('efficiencyValue').textContent = (currentScenario.cost_efficiency > 0 ? '+' : '') + currentScenario.cost_efficiency + '%';
}

// Calculate scenario impact
function calculateScenarioImpact() {
  const baseRevenue = 2300000000; // Q2 2025 forecast
  const baseMargin = 42.5;
  
  // Revenue impact calculation
  const marketingImpact = currentScenario.marketing_spend * 0.3;
  const priceImpact = currentScenario.price * 0.6;
  const hiringImpact = currentScenario.hiring_rate * 0.2;
  const churnImpact = -currentScenario.churn_target * 0.4;
  
  const totalRevenueImpact = marketingImpact + priceImpact + hiringImpact + churnImpact;
  const revenueChange = baseRevenue * (totalRevenueImpact / 100);
  
  // Margin impact calculation
  const marginImpact = (currentScenario.cost_efficiency * 0.15) - (currentScenario.marketing_spend * 0.05) - (currentScenario.hiring_rate * 0.08);
  
  // Timeline calculation
  const investmentLevel = Math.abs(currentScenario.marketing_spend) + Math.abs(currentScenario.hiring_rate);
  const timeline = Math.max(3, Math.round(investmentLevel / 5));
  
  // Risk score calculation
  const riskScore = Math.min(100, Math.abs(currentScenario.marketing_spend * 1.2) + Math.abs(currentScenario.price * 2) + Math.abs(currentScenario.hiring_rate * 1.5) + Math.abs(currentScenario.churn_target * 2.5));
  
  // Update UI
  document.getElementById('revenueImpact').textContent = (revenueChange > 0 ? '+$' : '-$') + Math.abs(revenueChange / 1000000).toFixed(1) + 'M';
  document.getElementById('revenueImpactPct').textContent = (totalRevenueImpact > 0 ? '+' : '') + totalRevenueImpact.toFixed(1) + '%';
  document.getElementById('revenueImpactPct').style.color = totalRevenueImpact >= 0 ? 'var(--color-success)' : 'var(--color-error)';
  
  document.getElementById('marginImpact').textContent = (marginImpact > 0 ? '+' : '') + marginImpact.toFixed(1) + '%';
  document.getElementById('marginImpactPct').textContent = (marginImpact > 0 ? '+' : '') + marginImpact.toFixed(1) + ' pts';
  document.getElementById('marginImpact').style.color = marginImpact >= 0 ? 'var(--color-success)' : 'var(--color-error)';
  
  document.getElementById('timelineImpact').textContent = timeline + ' months';
  document.getElementById('timelineNote').textContent = timeline <= 6 ? 'Fast ROI' : timeline <= 12 ? 'Moderate' : 'Long-term';
  
  document.getElementById('riskScore').textContent = Math.round(riskScore);
  document.getElementById('riskFill').style.width = riskScore + '%';
  
  // Color code risk
  const riskFill = document.getElementById('riskFill');
  if (riskScore < 30) {
    riskFill.style.background = 'var(--color-success)';
  } else if (riskScore < 60) {
    riskFill.style.background = 'var(--color-warning)';
  } else {
    riskFill.style.background = 'var(--color-error)';
  }
}

// Setup scenario buttons
function setupScenarioButtons() {
  document.getElementById('compareBtn').addEventListener('click', () => {
    alert('Compare Scenarios: This feature would show a side-by-side comparison of different scenario outcomes.');
  });
  
  document.getElementById('saveScenarioBtn').addEventListener('click', () => {
    alert('Scenario Saved: Your current scenario configuration has been saved successfully.');
  });
  
  document.getElementById('resetBtn').addEventListener('click', () => {
    currentScenario = {
      marketing_spend: 0,
      price: 0,
      hiring_rate: 0,
      churn_target: 0,
      cost_efficiency: 0
    };
    applyScenarioToSliders();
    calculateScenarioImpact();
  });
}

// Setup what-if analysis
function setupWhatIfAnalysis() {
  document.getElementById('analyzeBtn').addEventListener('click', () => {
    const input = document.getElementById('whatifInput').value;
    const kpiSelect = document.getElementById('kpiSelect').value;
    
    if (!input.trim()) {
      alert('Please enter a scenario to analyze.');
      return;
    }
    
    // Parse input and generate results
    const results = generateWhatIfResults(input, kpiSelect);
    displayWhatIfResults(results);
  });
}

// Generate what-if results
function generateWhatIfResults(input, kpiSelect) {
  const lowerInput = input.toLowerCase();
  const results = [];
  
  // Parse for marketing spend
  if (lowerInput.includes('marketing')) {
    const match = lowerInput.match(/(-?\d+)%/);
    if (match) {
      const change = parseInt(match[1]);
      results.push({
        label: 'Revenue Impact',
        value: (change * 0.3) >= 0 ? '+' + (change * 0.3).toFixed(1) + '%' : (change * 0.3).toFixed(1) + '%',
        positive: change * 0.3 >= 0
      });
      results.push({
        label: 'Margin Impact',
        value: (change * -0.05).toFixed(1) + ' pts',
        positive: change * -0.05 >= 0
      });
    }
  }
  
  // Parse for price changes
  if (lowerInput.includes('price')) {
    const match = lowerInput.match(/(-?\d+)%/);
    if (match) {
      const change = parseInt(match[1]);
      results.push({
        label: 'Revenue Impact',
        value: (change * 0.6) >= 0 ? '+' + (change * 0.6).toFixed(1) + '%' : (change * 0.6).toFixed(1) + '%',
        positive: change * 0.6 >= 0
      });
      results.push({
        label: 'Customer Churn',
        value: (change * 0.3).toFixed(1) + '%',
        positive: change * 0.3 <= 0
      });
    }
  }
  
  // Default results
  if (results.length === 0) {
    results.push(
      { label: 'Revenue Impact', value: '-3.8%', positive: false },
      { label: 'Margin Impact', value: '-1.2 pts', positive: false },
      { label: 'Customer Retention', value: '+2.1%', positive: true },
      { label: 'Timeline', value: '3-6 months', positive: true }
    );
  }
  
  return results;
}

// Display what-if results
function displayWhatIfResults(results) {
  const resultsContainer = document.getElementById('whatifResults');
  const resultGrid = document.getElementById('resultGrid');
  const timelineViz = document.getElementById('timelineViz');
  
  resultsContainer.style.display = 'block';
  
  // Clear previous results
  resultGrid.innerHTML = '';
  
  // Add result items
  results.forEach(result => {
    const resultItem = document.createElement('div');
    resultItem.className = 'result-item';
    resultItem.innerHTML = `
      <div class="result-label">${result.label}</div>
      <div class="result-value" style="color: ${result.positive ? 'var(--color-success)' : 'var(--color-error)'}">
        ${result.value}
      </div>
    `;
    resultGrid.appendChild(resultItem);
  });
  
  // Add timeline visualization
  timelineViz.innerHTML = `
    <strong>Impact Timeline:</strong>
    <div style="margin-top: 12px; display: flex; gap: 8px;">
      <div style="flex: 1; padding: 12px; background: var(--color-secondary); border-radius: 6px; text-align: center;">
        <div style="font-size: 12px; color: var(--color-text-secondary);">Q1</div>
        <div style="font-weight: 600; margin-top: 4px;">-2.5%</div>
      </div>
      <div style="flex: 1; padding: 12px; background: var(--color-secondary); border-radius: 6px; text-align: center;">
        <div style="font-size: 12px; color: var(--color-text-secondary);">Q2</div>
        <div style="font-weight: 600; margin-top: 4px;">-1.8%</div>
      </div>
      <div style="flex: 1; padding: 12px; background: var(--color-secondary); border-radius: 6px; text-align: center;">
        <div style="font-size: 12px; color: var(--color-text-secondary);">Q3</div>
        <div style="font-weight: 600; margin-top: 4px; color: var(--color-success);">+0.5%</div>
      </div>
      <div style="flex: 1; padding: 12px; background: var(--color-secondary); border-radius: 6px; text-align: center;">
        <div style="font-size: 12px; color: var(--color-text-secondary);">Q4</div>
        <div style="font-weight: 600; margin-top: 4px; color: var(--color-success);">+2.1%</div>
      </div>
    </div>
  `;
}

// Render charts
function renderCharts() {
  renderRevenueSegmentChart();
  renderRevenueForecastChart();
  renderMarginTrendsChart();
  renderChurnHeatmap();
}

// Update charts
function updateCharts() {
  if (charts.revenueSegment) charts.revenueSegment.destroy();
  if (charts.revenueForecast) charts.revenueForecast.destroy();
  if (charts.marginTrends) charts.marginTrends.destroy();
  
  renderRevenueSegmentChart();
  renderRevenueForecastChart();
  renderMarginTrendsChart();
  renderChurnHeatmap();
}

// Render revenue by segment chart
function renderRevenueSegmentChart() {
  const ctx = document.getElementById('revenueSegmentChart').getContext('2d');
  const data = dashboardData.finance.revenue_by_segment;
  
  charts.revenueSegment = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: data.map(d => d.segment),
      datasets: [{
        label: 'Revenue',
        data: data.map(d => d.revenue / 1000000000),
        backgroundColor: data.map(d => d.color),
        borderRadius: 8,
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (context) => {
              return '$' + context.parsed.y.toFixed(2) + 'B (' + data[context.dataIndex].percentage + '%)';
            }
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: (value) => '$' + value + 'B'
          },
          grid: { color: 'rgba(0,0,0,0.05)' }
        },
        x: {
          grid: { display: false }
        }
      }
    }
  });
}

// Render revenue forecast chart
function renderRevenueForecastChart() {
  const ctx = document.getElementById('revenueForecastChart').getContext('2d');
  const data = dashboardData.finance.revenue_forecast;
  
  const historicalData = data.filter(d => d.historical).map(d => d.revenue / 1000000000);
  const forecastData = data.filter(d => d.forecast).map(d => d.revenue / 1000000000);
  const upperBound = data.filter(d => d.forecast).map(d => d.upper_bound / 1000000000);
  const lowerBound = data.filter(d => d.forecast).map(d => d.lower_bound / 1000000000);
  
  // Combine for continuous line
  const allRevenue = [...historicalData, ...forecastData];
  const labels = data.map(d => d.quarter);
  
  charts.revenueForecast = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Historical Revenue',
          data: historicalData.concat(Array(forecastData.length).fill(null)),
          borderColor: '#3B82F6',
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          borderWidth: 3,
          fill: false,
          tension: 0.4,
          pointRadius: 5,
          pointHoverRadius: 7
        },
        {
          label: 'Forecast Revenue',
          data: Array(historicalData.length - 1).fill(null).concat([historicalData[historicalData.length - 1]]).concat(forecastData),
          borderColor: '#10B981',
          backgroundColor: 'rgba(16, 185, 129, 0.1)',
          borderWidth: 3,
          borderDash: [5, 5],
          fill: false,
          tension: 0.4,
          pointRadius: 5,
          pointHoverRadius: 7
        },
        {
          label: 'Upper Bound',
          data: Array(historicalData.length).fill(null).concat(upperBound),
          borderColor: 'rgba(16, 185, 129, 0.3)',
          backgroundColor: 'rgba(16, 185, 129, 0.05)',
          borderWidth: 1,
          fill: '+1',
          tension: 0.4,
          pointRadius: 0
        },
        {
          label: 'Lower Bound',
          data: Array(historicalData.length).fill(null).concat(lowerBound),
          borderColor: 'rgba(16, 185, 129, 0.3)',
          backgroundColor: 'rgba(16, 185, 129, 0.05)',
          borderWidth: 1,
          fill: false,
          tension: 0.4,
          pointRadius: 0
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: 'top',
          labels: {
            filter: (item) => item.text !== 'Upper Bound' && item.text !== 'Lower Bound'
          }
        },
        tooltip: {
          mode: 'index',
          intersect: false
        }
      },
      scales: {
        y: {
          beginAtZero: false,
          ticks: {
            callback: (value) => '$' + value.toFixed(1) + 'B'
          },
          grid: { color: 'rgba(0,0,0,0.05)' }
        },
        x: {
          grid: { display: false }
        }
      }
    }
  });
}

// Render margin trends chart
function renderMarginTrendsChart() {
  const ctx = document.getElementById('marginTrendsChart').getContext('2d');
  const data = dashboardData.finance.margin_trends;
  
  charts.marginTrends = new Chart(ctx, {
    type: 'line',
    data: {
      labels: data.map(d => d.quarter),
      datasets: [
        {
          label: 'Gross Margin',
          data: data.map(d => d.gross_margin),
          borderColor: '#8B5CF6',
          backgroundColor: 'rgba(139, 92, 246, 0.1)',
          borderWidth: 3,
          fill: true,
          tension: 0.4,
          pointRadius: 5
        },
        {
          label: 'Operating Margin',
          data: data.map(d => d.operating_margin),
          borderColor: '#EC4899',
          backgroundColor: 'rgba(236, 72, 153, 0.1)',
          borderWidth: 3,
          fill: true,
          tension: 0.4,
          pointRadius: 5
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: 'top'
        },
        tooltip: {
          mode: 'index',
          intersect: false,
          callbacks: {
            label: (context) => context.dataset.label + ': ' + context.parsed.y.toFixed(1) + '%'
          }
        }
      },
      scales: {
        y: {
          beginAtZero: false,
          ticks: {
            callback: (value) => value + '%'
          },
          grid: { color: 'rgba(0,0,0,0.05)' }
        },
        x: {
          grid: { display: false }
        }
      }
    }
  });
}

// Render churn heatmap
function renderChurnHeatmap() {
  const container = document.getElementById('churnHeatmap');
  const data = dashboardData.finance.churn_risk_heatmap;
  
  container.innerHTML = '';
  
  // Add header row
  const headerRow = document.createElement('div');
  headerRow.style.display = 'flex';
  headerRow.style.gap = '8px';
  headerRow.style.marginBottom = '8px';
  headerRow.style.paddingLeft = '100px';
  
  data.regions.forEach(region => {
    const header = document.createElement('div');
    header.style.flex = '1';
    header.style.textAlign = 'center';
    header.style.fontSize = '11px';
    header.style.fontWeight = '600';
    header.style.color = 'var(--color-text-secondary)';
    header.textContent = region;
    headerRow.appendChild(header);
  });
  container.appendChild(headerRow);
  
  // Add data rows
  data.risk_matrix.forEach((row, rowIndex) => {
    const rowDiv = document.createElement('div');
    rowDiv.className = 'heatmap-row';
    rowDiv.style.display = 'flex';
    rowDiv.style.gap = '8px';
    rowDiv.style.alignItems = 'center';
    
    // Add row label
    const label = document.createElement('div');
    label.style.width = '100px';
    label.style.fontSize = '11px';
    label.style.fontWeight = '600';
    label.style.color = 'var(--color-text-secondary)';
    label.textContent = row.segment;
    rowDiv.appendChild(label);
    
    // Add cells
    row.risks.forEach((risk, colIndex) => {
      const cell = document.createElement('div');
      cell.className = 'heatmap-cell';
      
      // Color based on risk
      let bgColor;
      if (risk < 20) {
        bgColor = 'rgba(16, 185, 129, 0.7)'; // Green
      } else if (risk < 40) {
        bgColor = 'rgba(245, 158, 11, 0.6)'; // Yellow
      } else if (risk < 60) {
        bgColor = 'rgba(249, 115, 22, 0.7)'; // Orange
      } else {
        bgColor = 'rgba(239, 68, 68, 0.8)'; // Red
      }
      
      cell.style.background = bgColor;
      cell.innerHTML = `
        <div class="heatmap-value">${risk}%</div>
      `;
      
      cell.addEventListener('click', () => {
        alert(`Churn Risk Details\n\nSegment: ${row.segment}\nRegion: ${data.regions[colIndex]}\nRisk: ${risk}%\n\nClick to drill down for detailed analysis.`);
      });
      
      rowDiv.appendChild(cell);
    });
    
    container.appendChild(rowDiv);
  });
  
  // Add legend
  const legend = document.createElement('div');
  legend.className = 'heatmap-legend';
  legend.innerHTML = `
    <div style="display: flex; align-items: center; gap: 4px;">
      <div style="width: 16px; height: 16px; background: rgba(16, 185, 129, 0.7); border-radius: 4px;"></div>
      <span>Low (0-20%)</span>
    </div>
    <div style="display: flex; align-items: center; gap: 4px;">
      <div style="width: 16px; height: 16px; background: rgba(245, 158, 11, 0.6); border-radius: 4px;"></div>
      <span>Medium (20-40%)</span>
    </div>
    <div style="display: flex; align-items: center; gap: 4px;">
      <div style="width: 16px; height: 16px; background: rgba(249, 115, 22, 0.7); border-radius: 4px;"></div>
      <span>High (40-60%)</span>
    </div>
    <div style="display: flex; align-items: center; gap: 4px;">
      <div style="width: 16px; height: 16px; background: rgba(239, 68, 68, 0.8); border-radius: 4px;"></div>
      <span>Critical (60%+)</span>
    </div>
  `;
  container.appendChild(legend);
}

// Render recommendations
function renderRecommendations() {
  const container = document.getElementById('recommendationsGrid');
  const recommendations = dashboardData.finance.ai_recommendations;
  
  container.innerHTML = '';
  
  recommendations.forEach(rec => {
    const card = document.createElement('div');
    card.className = 'recommendation-card';
    
    // Set priority color
    const priorityColor = rec.priority === 'high' ? 'var(--color-error)' : 
                         rec.priority === 'medium' ? 'var(--color-warning)' : 
                         'var(--color-success)';
    card.style.setProperty('--priority-color', priorityColor);
    
    card.innerHTML = `
      <div class="recommendation-header">
        <div class="recommendation-title">${rec.title}</div>
        <div class="recommendation-impact">${rec.impact}</div>
      </div>
      <div class="recommendation-action">${rec.action}</div>
      <div class="recommendation-meta">
        <div>⏱️ ${rec.time_to_implement}</div>
        <div class="confidence-score">
          <span>Confidence:</span>
          <div class="confidence-bar">
            <div class="confidence-fill" style="width: ${rec.confidence}%;"></div>
          </div>
          <span>${rec.confidence}%</span>
        </div>
      </div>
      <button class="recommendation-action-btn">Apply Recommendation</button>
    `;
    
    // Add click handler
    card.querySelector('.recommendation-action-btn').addEventListener('click', () => {
      alert(`Applying Recommendation: ${rec.title}\n\nThis would integrate the recommendation into your scenario planning.`);
    });
    
    container.appendChild(card);
  });
}

// Initialize on load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}